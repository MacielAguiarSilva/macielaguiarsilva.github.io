var logo = document.querySelector('.logo');
var lupa = document.querySelector('.lupa');
var btn = document.querySelector('.btnMenu');
var v = document.querySelector('.x');
var itens = document.querySelector('.itens');

lupa.onclick = () => {
  logo.style='display:none';
  btn.style='display:none';
  lupa.style='width:100vw; margin:0';
  v.style='display:block'
}
function pesquisa() {
  itens.style = 'display:block';
  
  input = lupa.value;
  input = input.toLowerCase();
  let x=document.getElementsByClassName('item');
  
  for (i = 0; i < x.length; i++) {
    if (!x[i].innerHTML.toLowerCase().includes(input)) {
      x[i].style.display = "none";
    }
    else {
      x[i].style.display = "list-item";
    }
  }
}
function voltarPesquisa() {
  logo.style = 'display:block';
  btn.style = 'display:block';
  lupa.style = 'width:30%';
  v.style = 'display:none';
  itens.style = 'display:none';
}

// MENU

let menu = document.querySelector('.menu-pai');
let btnMenu= document.querySelector('.btnMenu');
let overlay= document.getElementById('overlay');

btnMenu.onclick = () => {
  menu.classList.toggle("active-menu");
  overlay.classList.toggle("overlay");
}
overlay.onclick =()=> {
 overlay.classList.toggle("overlay");
  menu.classList.toggle("active-menu");
}
// fim MENU

