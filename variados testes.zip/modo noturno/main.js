var c = document.querySelector('.container');
var classe = c.getAttribute('class');
var fbtn = document.querySelector('.btn');
var html = document.querySelector('html');
var n = 0;
function btn() {
  if (classe === 'container') {
    c.classList.toggle('end');
    func(n++)
  }
}
function func() {
  if (n % 2 == 1) {
    html.style = 'background:black ;color:white;';
    fbtn.style = 'border: 22.5px solid white;';
    c.style = 'border: 4px solid white;';
  }
  else {
    html.style = 'background:white ;color:black;';
    fbtn.style = 'border: 22.5px solid black;';
    c.style = 'border: 4px solid black;';
  }
}